LET IT DIE Offline - Borderless 0.1.1

Windows x64 Steam offline edition.

FEATURES
Borderless fullscreen, allowing desktop chat overlays above the game.
This version provides borderless mode only. For the texture fix as well,
choose Borderless + Texture Fix 0.2.0 from the repository.

INSTALL
1. Close the game. In Steam, select Manage > Browse local files.
2. Open Binaries\Win64, the folder containing BrgGame-Steam.exe.
3. Back up any existing d3d9.dll outside the game folder.
4. Copy this package's d3d9.dll into Binaries\Win64.
5. Enable Fullscreen in the game settings and launch normally.

Install one wrapper at a time. Other mods supplying d3d9.dll cannot be
installed alongside this one directly. No launch options or hotkeys are
required. Do not edit SteamPCRelease-BrgEngine.ini or
SteamPCRelease-BrgGHMEngine.ini.

COMPATIBILITY AND TESTING
Borderless mode was confirmed working in-game with a desktop chat overlay.
Other game builds, multi-monitor setups and other graphics wrappers are
unverified.

REMOVE
Close the game and delete this package's d3d9.dll, or restore your backed-up
DLL. Restore your graphics configuration if you changed it manually.

SOURCE, DOCUMENTATION AND SUPPORT
https://github.com/JayKayCreep/LET-IT-DIE-Offline-fixes

Report problems through the repository's Issues page with the fix version,
game version, Windows version, GPU, other graphics mods and reproduction
steps. SHA256SUMS.txt contains the DLL checksum.

MIT licence; see LICENSE and NOTICE.md.
