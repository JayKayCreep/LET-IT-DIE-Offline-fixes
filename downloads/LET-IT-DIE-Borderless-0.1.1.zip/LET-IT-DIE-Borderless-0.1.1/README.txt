LET-IT-DIE-Borderless-0.1.1

Borderless windowed mode only.

Close LET IT DIE. Back up any existing d3d9.dll outside the game folder, then copy this DLL into Binaries\Win64 beside BrgGame-Steam.exe. Use the game's Fullscreen setting (mbFullScreen=True). Do not edit the protected SteamPCRelease engine INIs. Install only one wrapper at a time.

No logging, hotkeys or background window enforcement. Close the game and remove/replace this DLL to uninstall.

Documentation and source: https://github.com/jaykcreep/let-it-die-pc-fixes
