LET-IT-DIE-Borderless-Texture-Fix-0.2.0

Borderless mode plus automatic engine mip-fade disabling on the supported executable. Automatic startup behavior still needs in-game confirmation.

Close LET IT DIE. Back up any existing d3d9.dll outside the game folder, then copy this DLL into Binaries\Win64 beside BrgGame-Steam.exe. Use the game's Fullscreen setting (mbFullScreen=True). Do not edit the protected SteamPCRelease engine INIs. Install only one wrapper at a time.

No logging, hotkeys or background window enforcement. Close the game and remove/replace this DLL to uninstall.

Documentation and source: https://github.com/jaykcreep/let-it-die-pc-fixes

Texture-fix executable SHA256: 716046F09F398A61B359CC1DD08366F3FD1D867605949D6729E25C3A07A4DBAF. On mismatch, the texture setting is left unchanged; borderless mode remains.
