LET IT DIE Offline - Borderless + Texture Fix 0.2.0

Windows x64 Steam offline edition.

FEATURES
- Borderless fullscreen, allowing desktop chat overlays above the game.
- Automatic removal of the engine's mip-fade transition to address the
  tested texture blur and delayed sharpening.

INSTALL
1. Close the game. In Steam, select Manage > Browse local files.
2. Open Binaries\Win64, the folder containing BrgGame-Steam.exe.
3. Back up any existing d3d9.dll outside the game folder.
4. Copy this package's d3d9.dll into Binaries\Win64.
5. Enable Fullscreen in the game settings and launch normally.

Install one wrapper at a time. Other mods supplying d3d9.dll cannot be
installed alongside this one directly. No launch options or hotkeys are
required. Do not edit SteamPCRelease-BrgEngine.ini or
SteamPCRelease-BrgGHMEngine.ini.

COMPATIBILITY AND TESTING
The maintainer tested the automatic texture fix for several hours in-game
with no crashes or other issues observed.

The texture fix applies only after executable and engine checks pass.
Supported BrgGame-Steam.exe SHA-256:
716046F09F398A61B359CC1DD08366F3FD1D867605949D6729E25C3A07A4DBAF

If checks fail, the texture setting is left unchanged; borderless mode
remains available. Game updates require revalidation. Other game builds,
multi-monitor setups and other graphics wrappers are unverified.

This fixes the tested mip-fade blur; it does not guarantee maximum detail
for every texture or resolve all streaming problems.

REMOVE
Close the game and delete this package's d3d9.dll, or restore your backed-up
DLL. Restore your graphics configuration if you changed it manually.
Launching without this DLL restores normal engine mip fading.

SOURCE, DOCUMENTATION AND SUPPORT
https://github.com/JayKayCreep/LET-IT-DIE-Offline-fixes

Report problems through the repository's Issues page with the fix version,
game version, Windows version, GPU, other graphics mods and reproduction
steps. SHA256SUMS.txt contains the DLL checksum.

MIT licence; see LICENSE and NOTICE.md.
